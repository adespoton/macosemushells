This folder contains two qemu vga drivers:

qemu_vga_NO256.ndrv is the latest version of the driver, but it doesn't support 256 colours/greyscale
qemu_vga_256.ndrv is the older driver which does support 256 colours and greyscale.

Rename the desired file to qemu_vga.ndrv and put it in the Qemu folder.

Note that the qemu command needs to contain -prom-env "vga-ndrv?=true" to load the driver.